class Human:
    endurance_min = 100
    power_kN = 100
    intelligence_IQ = 120
    height_sm = 150
    weight_kg = 60
    skin_color = "Skin's color"
    location = "Earth"
class UNICO(Human):
    intelligence_IQ = 160
class Aliens(Human):
    endurance_min = 200
    power_kN = 15
    intelligence_IQ = 500
    height_sm = 75
    weight_kg = 20
    skin_color = "BLue"
    location = "Space"
    planeLight_m = 100